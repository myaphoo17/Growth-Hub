import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-C572IFO5.js";
import "./chunk-C6YNR27T.js";
import "./chunk-DZCQHPGA.js";
import "./chunk-SFL7S376.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-DUV3ZHQV.js";
import "./chunk-MJQNUHK2.js";
import "./chunk-MOY5LPCH.js";
import "./chunk-SAI3DHVA.js";
import "./chunk-IEMOZLTW.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
