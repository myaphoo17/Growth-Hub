import { Component } from '@angular/core';

@Component({
  selector: 'app-student-help-center',
  templateUrl: './student-help-center.component.html',
  styleUrl: './student-help-center.component.css'
})
export class StudentHelpCenterComponent {

}
