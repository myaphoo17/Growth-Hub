export interface forGetPassModel {
    otp: string;
    email: string;
    message:string;
    newPass:string;
  }