import { Component } from '@angular/core';

@Component({
  selector: 'app-message-home',
  templateUrl: './message-home.component.html',
  styleUrl: './message-home.component.css'
})
export class MessageHomeComponent {

}
