export interface ObjectModel{
    category:string;
    courseTitle:string;
    courseDescription:string;
    courseCreatorId:string;
    courseDuration:string;
    sectionTitle:string;
}