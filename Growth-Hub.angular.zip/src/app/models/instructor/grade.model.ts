export interface GradeModel {
  id:number;
  name: string;
  minPoints: number;
  maxPoints: number;
  courseId: number;
}
