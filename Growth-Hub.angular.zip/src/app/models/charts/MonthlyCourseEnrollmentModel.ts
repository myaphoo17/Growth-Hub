// In a new file, e.g., models/MonthlyCourseEnrollmentModel.ts
export interface MonthlyCourseEnrollmentModel {
    month: number;
    courseId: number;
    courseName: string;
    studentCount: number;
  }
  