export interface MonthlyDataModel {
    month: number;
    studentEnrollments: number;
    coursesCreated: number;
  }
  