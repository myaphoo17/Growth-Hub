export interface EditEducationModel{
    courseId:string;
    title:string;
    id:string;
    url:string;
}