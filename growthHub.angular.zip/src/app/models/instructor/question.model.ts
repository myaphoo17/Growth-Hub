import { OptionModel } from "./option.model";
export interface QuestionModel {
    title: string;
    options: OptionModel[];
  }