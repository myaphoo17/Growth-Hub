export interface CategoriesDTO {
  name: string;
}