export interface Education {
    id:string;
    institution: string;
    degree: string;
    startDate: string;
    graduationDate: string;
  }
  