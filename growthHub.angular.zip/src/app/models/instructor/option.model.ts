export interface OptionModel {
    
    text: string;
    isCorrect: boolean;
    points: number;
  }