import { Component } from '@angular/core';

@Component({
  selector: 'app-student-view-course',
  templateUrl: './student-view-course.component.html',
  styleUrl: './student-view-course.component.css'
})
export class StudentViewCourseComponent {

}
