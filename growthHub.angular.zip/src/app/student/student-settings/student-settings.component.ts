import { Component } from '@angular/core';

@Component({
  selector: 'app-student-settings',
  templateUrl: './student-settings.component.html',
  styleUrl: './student-settings.component.css'
})
export class StudentSettingsComponent {

}
