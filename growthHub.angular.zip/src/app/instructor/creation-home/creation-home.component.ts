import { Component } from '@angular/core';

@Component({
  selector: 'app-creation-home',
  templateUrl: './creation-home.component.html',
  styleUrl: './creation-home.component.css'
})
export class CreationHomeComponent {

}
