import { Component } from '@angular/core';

@Component({
  selector: 'app-int-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class InstructorHomeComponent {

}
