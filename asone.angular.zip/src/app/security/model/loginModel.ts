export interface loginModel {
    staffId: string;
    password: string;
  }
  