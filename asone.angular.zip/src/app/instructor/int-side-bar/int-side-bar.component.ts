import { Component } from '@angular/core';

@Component({
  selector: 'app-int-side-bar',
  templateUrl: './int-side-bar.component.html',
  styleUrl: './int-side-bar.component.css'
})
export class IntSideBarComponent {

}
