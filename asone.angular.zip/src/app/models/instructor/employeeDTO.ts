export interface employeeDTO{
    sr:string;
    division :string;
    staffId:string;
    name:string;
    doorLogNo:string;
    department:string;
    team:string;
    email:string;
    status:string;
    role:string;
    profile:string;
    PhotoUrl:string;
}