export interface Employer{
    sr:number;
    division:string;
    staffId:string;
    name:string;
    doorLogNo:string;
    department:string;
    team:string;
    email:string;
    status:string;
    role:string;
    defaultPasswrod:string;
    profilePhotoUrl:string;
}