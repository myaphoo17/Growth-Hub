export interface ApproveModel{
    courseId:string;
    adminId:string;
}